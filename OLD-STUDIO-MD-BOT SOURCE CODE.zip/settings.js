module.exports = {
    giphyApiKey: process.env.GIPHY_API_KEY || 'dc6zaTOxFJmzC',
    ownerNumber: process.env.OWNER_NUMBER || 923134169814',
    botName: '𓆩⚡𝙈𝘼𝙉𝙄 𝘾𝙔𝘽𝙀𝙍-𝙈𝘿⚡𓆪',
    ownerName: '𓆩👑𝙈𝘼𝙉𝙄 𝙆𝙄𝙉𝙂👑𓆪'
};
