const settings = require('../settings');

async function ownerCommand(sock, from, msg) {
    const ownerText = `👤 *𓆩👑𝙈𝘼𝙉𝙄 𝙆𝙄𝙉𝙂👑𓆪:* ${settings.ownerName}\n` +
                    `📱 *923134169814:* +${settings.ownerNumber}\n` +
                    `🔗 *OFFICIAL WHATSAPP CHANNEL:*\n` +
                    `> *https://whatsapp.com/channel/0029VbAkXZO6WaKm6826Fj3S*`;
    await sock.sendMessage(from, { text: ownerText }, { quoted: msg });
}

module.exports = ownerCommand;
